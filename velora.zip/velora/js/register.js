const registerBtn =
document.getElementById("register-btn");

registerBtn.addEventListener("click", () => {

  const username =
  document.getElementById(
    "register-username"
  ).value;

  const password =
  document.getElementById(
    "register-password"
  ).value;

  if(username === "" || password === ""){

    alert("Fill all inputs");

    return;

  }

  const user = {

    username,
    password

  };

  localStorage.setItem(
    "veloraUser",
    JSON.stringify(user)
  );

  alert("Account Created");

  window.location.href =
  "login.html";

});