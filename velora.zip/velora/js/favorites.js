/* favorites.js */

/* =========================
   ELEMENTS
========================= */

const favoritesGrid =
document.querySelector(".favorites-grid");

/* =========================
   GET FAVORITES
========================= */

let favorites =
JSON.parse(
  localStorage.getItem("favorites")
) || [];

console.log(favorites);

/* =========================
   EMPTY FAVORITES
========================= */

if(favorites.length === 0){

  favoritesGrid.innerHTML = `

    <div class="empty-favorites">

      <i class="fa-solid fa-heart-crack"></i>

      <h2>

        No Favorite Movies Yet

      </h2>

    </div>

  `;

}

/* =========================
   RENDER FAVORITES
========================= */

favorites.forEach(movie => {

  favoritesGrid.innerHTML += `

    <div class="movie-card">

      <img
        src="${movie.image}"
      >

      <div class="movie-overlay">

        <h3>

          ${movie.title}

        </h3>

        <span>

          ${movie.rating}

        </span>

      </div>

    </div>

  `;

});