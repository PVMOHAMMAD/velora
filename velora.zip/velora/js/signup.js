const signupBtn =
document.getElementById(
  "signup-btn"
);

signupBtn.addEventListener(
  "click",
  () => {

    const username =
    document.getElementById(
      "signup-username"
    ).value;

    const email =
    document.getElementById(
      "signup-email"
    ).value;

    const password =
    document.getElementById(
      "signup-password"
    ).value;

    if(
      !username ||
      !email ||
      !password
    ){

      alert("Fill all fields");

      return;

    }

    const user = {

      username,
      email,
      password

    };

    localStorage.setItem(
      "user",
      JSON.stringify(user)
    );

    alert(
      "Account Created"
    );

    window.location.href =
    "login.html";

  }
);