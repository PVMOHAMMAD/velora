const profileName =
document.getElementById("profile-name");

const logoutBtn =
document.getElementById("logout-btn");

const loggedInUser =
localStorage.getItem("loggedInUser");

if(!loggedInUser){

  window.location.href =
  "login.html";

}

profileName.textContent =
`Welcome ${loggedInUser}`;

logoutBtn.addEventListener("click", () => {

  localStorage.removeItem(
    "loggedInUser"
  );

  window.location.href =
  "login.html";

});
const user =
JSON.parse(
  localStorage.getItem("user")
);

if(!user){

  window.location.href =
  "login.html";

}

document.getElementById(
  "profile-name"
).textContent =
user.username;

document.getElementById(
  "profile-email"
).textContent =
user.email;

document.getElementById(
  "logout-btn"
).addEventListener(
  "click",
  () => {

    localStorage.removeItem(
      "loggedIn"
    );

    window.location.href =
    "login.html";

  }
);