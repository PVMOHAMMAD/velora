const loginBtn =
document.getElementById(
  "login-btn"
);

loginBtn.addEventListener(
  "click",
  () => {

    const email =
    document.getElementById(
      "login-email"
    ).value;

    const password =
    document.getElementById(
      "login-password"
    ).value;

    const savedUser =
    JSON.parse(
      localStorage.getItem("user")
    );

    if(!savedUser){

      alert("No Account Found");

      return;

    }

    if(

      savedUser.email === email &&
      savedUser.password === password

    ){

      localStorage.setItem(
        "loggedIn",
        "true"
      );

      alert("Login Success");

      window.location.href =
      "profile.html";

    }else{

      alert("Wrong Email Or Password");

    }

  }
);