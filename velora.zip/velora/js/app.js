const API_KEY =
"ea3395e6492a9f9eb069f7e4d277db48";

console.log("Movie Site Loaded");

/* =========================
   CURRENT MOVIE
========================= */

let currentMovie = null;

/* =========================
   ELEMENTS
========================= */



const moviesContainer =
document.querySelector(".movies-container");

const movieModal =
document.querySelector(".movie-modal");

const closeModal =
document.querySelector(".close-modal");

const searchInput =
document.getElementById("search-input");

const favoriteBtn =
document.querySelector(".favorite-btn");

/* =========================
   GET TRENDING MOVIES
========================= */

async function getTrendingMovies(){

  try{

    const response = await fetch(

`https://api.themoviedb.org/3/trending/movie/week?api_key=${API_KEY}&language=fa-IR`

    );

    const data = await response.json();

    console.log(data);

    moviesContainer.innerHTML = "";

    data.results.forEach(movie => {

      if(!movie.poster_path) return;

      moviesContainer.innerHTML += `

        <div class="movie-card">

          <img
            src="https://image.tmdb.org/t/p/original${movie.poster_path}"
          >

          <div class="movie-overlay">

  <h3>

    ${movie.original_title}

  </h3>

  <span>

    ⭐ ${movie.vote_average.toFixed(1)}

  </span>

  <div class="hover-buttons">

    <button
      class="play-hover-btn"
    >

      ▶ Play

    </button>

    <button
      class="info-hover-btn"
    >

      More Info

    </button>

  </div>

</div>

        </div>

      `;

    });

    activateMovieCards(data.results);

  }catch(error){

    console.log(error);

  }

}

getTrendingMovies();

enableDragScroll(moviesContainer);

/* =========================
   CATEGORY MOVIES
========================= */

async function getCategoryMovies(
  url,
  containerId
){

  try{

    const response =
    await fetch(url);

    const data =
    await response.json();

    const container =
    document.getElementById(
      containerId
    );

    container.innerHTML = "";

    data.results.forEach(movie => {

      if(!movie.poster_path) return;

      container.innerHTML += `

        <div class="movie-card">

          <img
            src="https://image.tmdb.org/t/p/original${movie.poster_path}"
          >

          <div class="movie-overlay">

  <h3>

    ${movie.original_title}

  </h3>

  <span>

    ⭐ ${movie.vote_average.toFixed(1)}

  </span>

  <div class="hover-buttons">

    <button
      class="play-hover-btn"
    >

      ▶ Play

    </button>

    <button
      class="info-hover-btn"
    >

      More Info

    </button>

  </div>

</div>

        </div>

      `;

    });

    activateMovieCards(data.results);

    enableDragScroll(container);

  }catch(error){

    console.log(error);

  }

}

/* =========================
   ACTIVATE MOVIE CARDS
========================= */

function activateMovieCards(movies){

  const movieCards =
  document.querySelectorAll(".movie-card");

  movieCards.forEach((card,index) => {

    card.addEventListener("click", () => {

      const movie = movies[index];

      /* CURRENT MOVIE */

      currentMovie = {

        title: movie.title,

        image:
`https://image.tmdb.org/t/p/original${movie.poster_path}`,

        rating:
`⭐ ${movie.vote_average.toFixed(1)}`

      };

      /* MODAL CONTENT */

      document.getElementById(
        "modal-title"
      ).textContent =
      movie.original_title;

      document.getElementById(
        "modal-description"
      ).textContent =
      movie.overview ||
      "No description available"

      document.getElementById(
        "modal-rating"
      ).textContent =
`⭐ ${movie.vote_average.toFixed(1)}`;

      document.getElementById(
        "modal-genre"
      ).textContent =
      "Trending";

      document.getElementById(
        "modal-year"
      ).textContent =
      movie.release_date
      ? movie.release_date.split("-")[0]
      : "2025";

      document.getElementById(
        "modal-poster"
      ).src =
`https://image.tmdb.org/t/p/original${movie.poster_path}`;

      /* FAVORITE ACTIVE */

      let favorites =
      JSON.parse(
        localStorage.getItem("favorites")
      ) || [];

      const exists =
      favorites.find(f => {

        return f.title === currentMovie.title;

      });

      if(exists){

        favoriteBtn.classList.add("active");

      }else{

        favoriteBtn.classList.remove("active");

      }

      /* OPEN MODAL */

      movieModal.classList.add("active");

    });

  });

}

/* =========================
   CLOSE MODAL
========================= */

closeModal.addEventListener("click", () => {

  movieModal.classList.remove("active");

});

movieModal.addEventListener("click", (e) => {

  if(e.target === movieModal){

    movieModal.classList.remove("active");

  }

});

/* =========================
   FAVORITES
========================= */

favoriteBtn.onclick = function(){

  console.log(currentMovie);

  if(!currentMovie){

    alert("No movie selected");

    return;

  }

  let favorites =
  JSON.parse(
    localStorage.getItem("favorites")
  ) || [];

  const exists =
  favorites.find(movie => {

    return movie.title === currentMovie.title;

  });

  if(exists){

    favorites =
    favorites.filter(movie => {

      return movie.title !== currentMovie.title;

    });

    favoriteBtn.classList.remove("active");

    console.log("Removed From Favorites");

  }else{

    favorites.push(currentMovie);

    favoriteBtn.classList.add("active");

    console.log("Added To Favorites");

  }

  localStorage.setItem(

    "favorites",

    JSON.stringify(favorites)

  );

  console.log(

    localStorage.getItem("favorites")

  );

};

/* =========================
   SEARCH
========================= */

searchInput.addEventListener("input", () => {

  const value =
  searchInput.value.toLowerCase();

  const movieCards =
  document.querySelectorAll(".movie-card");

  movieCards.forEach(card => {

    const movieName =
    card.querySelector("h3")
    .textContent
    .toLowerCase();

    if(movieName.includes(value)){

      card.style.display = "block";

    }else{

      card.style.display = "none";

    }

  });

});

/* =========================
   DRAG SCROLL
========================= */

let isDown = false;

let startX;

let scrollLeft;

moviesContainer.addEventListener("mousedown", (e) => {

  isDown = true;

  startX =
  e.pageX - moviesContainer.offsetLeft;

  scrollLeft =
  moviesContainer.scrollLeft;

});

moviesContainer.addEventListener("mouseleave", () => {

  isDown = false;

});

moviesContainer.addEventListener("mouseup", () => {

  isDown = false;

});

moviesContainer.addEventListener("mousemove", (e) => {

  if(!isDown) return;

  e.preventDefault();

  const x =
  e.pageX - moviesContainer.offsetLeft;

  const walk =
  (x - startX) * 2;

  moviesContainer.scrollLeft =
  scrollLeft - walk;

});

/* =========================
   HERO
========================= */

async function updateHero(){

  try{

    const response = await fetch(

`https://api.themoviedb.org/3/trending/movie/week?api_key=${API_KEY}&language=fa-IR`

    );

    const data = await response.json();

    const randomIndex = Math.floor(

  Math.random() * data.results.length

);

const heroMovie =
data.results[randomIndex];

    document.getElementById(
      "hero-title"
    ).textContent =
    heroMovie.original_title;

    document.getElementById(
      "hero-description"
    ).textContent =
    heroMovie.overview ||
    "No description available"

    document.getElementById(
      "hero-rating"
    ).textContent =
`⭐ ${heroMovie.vote_average.toFixed(1)}`;

    document.getElementById(
      "hero-genre"
    ).textContent =
    "Trending";

    document.getElementById(
      "hero-year"
    ).textContent =
    heroMovie.release_date
    ? heroMovie.release_date.split("-")[0]
    : "2025";

    document.getElementById(
      "hero-poster"
    ).src =
`https://image.tmdb.org/t/p/original${heroMovie.poster_path}`;

    document.querySelector(".hero")
    .style.backgroundImage =

`url(https://image.tmdb.org/t/p/original${heroMovie.backdrop_path})`;

  }catch(error){

    console.log(error);

  }

}


updateHero();
/* =========================
   PROFILE LINK
========================= */

const profileLink =
document.getElementById("profile-link");

const loggedInUser =
localStorage.getItem("loggedInUser");

if(!loggedInUser){

  profileLink.href = "login.html";

}else{

  profileLink.href = "profile.html";

}
/* =========================
   LOAD CATEGORIES
========================= */

getCategoryMovies(

`https://api.themoviedb.org/3/discover/movie?api_key=${API_KEY}&with_genres=28&language=fa-IR`,

"action-container"

);

getCategoryMovies(

`https://api.themoviedb.org/3/discover/movie?api_key=${API_KEY}&with_genres=27&language=fa-IR`,

"horror-container"

);

getCategoryMovies(

`https://api.themoviedb.org/3/movie/top_rated?api_key=${API_KEY}&language=fa-IR`,

"toprated-container"

);

getCategoryMovies(

`https://api.themoviedb.org/3/discover/movie?api_key=${API_KEY}&with_genres=878&language=fa-IR`,

"scifi-container"

);

getCategoryMovies(
  `https://api.themoviedb.org/3/discover/movie?api_key=${API_KEY}&with_genres=16&language=fa-IR`,
  "anime-container"
);

getCategoryMovies(
  `https://api.themoviedb.org/3/discover/movie?api_key=${API_KEY}&with_genres=80&language=fa-IR`,
  "crime-container"
);
/* =========================
   DRAG SCROLL FUNCTION
========================= */

function enableDragScroll(container){

  let isDown = false;

  let startX;

  let scrollLeft;

  container.addEventListener(
    "mousedown",
    (e) => {

      isDown = true;

      startX =
      e.pageX - container.offsetLeft;

      scrollLeft =
      container.scrollLeft;

    }
  );

  container.addEventListener(
    "mouseleave",
    () => {

      isDown = false;

    }
  );

  container.addEventListener(
    "mouseup",
    () => {

      isDown = false;

    }
  );

  container.addEventListener(
    "mousemove",
    (e) => {

      if(!isDown) return;

      e.preventDefault();

      const x =
      e.pageX - container.offsetLeft;

      const walk =
      (x - startX) * 2;

      container.scrollLeft =
      scrollLeft - walk;

    }
  );

}
/* =========================
   VIEW ALL BUTTONS
========================= */

const viewAllButtons =
document.querySelectorAll(
  ".view-all-btn"
);

viewAllButtons.forEach(button => {

  button.addEventListener(
    "click",
    async () => {

      const genreId =
      button.dataset.genre;

      const genreTitle =
      button.dataset.title;

      try{

        const response =
        await fetch(

`https://api.themoviedb.org/3/discover/movie?api_key=${API_KEY}&with_genres=${genreId}&language=fa-IR`

        );

        const data =
        await response.json();

        moviesContainer.innerHTML = "";

        document.querySelector(
          ".section-header h2"
        ).textContent =
        genreTitle;

        data.results.forEach(movie => {

          if(!movie.poster_path)
          return;

          moviesContainer.innerHTML += `

            <div class="movie-card">

              <img
                src="https://image.tmdb.org/t/p/w500${movie.poster_path}"
              >

              <div class="movie-overlay">

  <h3>

    ${movie.original_title}

  </h3>

  <span>

    ⭐ ${movie.vote_average.toFixed(1)}

  </span>

  <div class="hover-buttons">

    <button
      class="play-hover-btn"
    >

      ▶ Play

    </button>

    <button
      class="info-hover-btn"
    >

      More Info

    </button>

  </div>

</div>
            </div>

          `;

        });

        activateMovieCards(
          data.results
        );

      }catch(error){

        console.log(error);

      }

    }
  );

});